<?php
$host ="localhost";
$user ="root";
$pass ="absen1234";
$db ="absensi_hd";
$conn = mysqli_connect($host,$user,$pass,$db) or die ("Koneksi gagal"); 
?>